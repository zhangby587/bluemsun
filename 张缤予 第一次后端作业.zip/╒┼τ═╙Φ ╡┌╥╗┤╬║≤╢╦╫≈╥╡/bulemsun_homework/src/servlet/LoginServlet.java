package servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginServlet extends HttpServlet {

//    public LoginServlet() {
//        super();
//    }
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        doPost(request,response);
    }
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Users u = new Users();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        u.setUsername(username);
        u.setPassword(password);
        //如果用户名使Mary，密码是1128，则成功
        if(u.getUsername().equals("Mary")&&u.getPassword().equals("1128"))
        {
            response.sendRedirect(request.getContextPath()+"/login_success.jsp");
        }
        else
        {
            response.sendRedirect(request.getContextPath()+"/login_failure.jsp");
        }
    }

}

